import java.util.*;

class process
{    	int job;
        String name[]=new String[50];
        int a[]=new int[50];  
        int Arrival[]=new int[50];
        int Burst[]=new int[50];
        int Wt[]=new int[50];
        int TAT[]=new int[50];
        int CT[]=new int[50];
        int temp;
        float avg,avg1;
         
  
   //public static void main(String s[])   
   process()
   { 
    Scanner sc=new Scanner(System.in);
      System.out.println("enter no of jobs");
       job=sc.nextInt();
    
    
    for(int i=0;i<job;i++)
     {
      System.out.println("enter the name of job");
      name[i]=sc.next();

      System.out.println("enter the arrival time");
      Arrival[i]=sc.nextInt();

      System.out.println("enter the burst");
      Burst[i]=sc.nextInt();
                  
     }
    } 

public void sort()
{
     for(int i=0;i<job;i++)
     {
         for(int j=i+1;j<job;j++)
         {
             if(Arrival[i]>Arrival[j])
             {
                  temp=a[i];
                  a[i]=a[j];
                  a[j]=temp;
             }
         } 
     }
}    

public void opt()
{
  sort();
   Wt[0]=0;TAT[0]=Burst[0];CT[0]=Burst[0];
   for(int i=1;i<job+1;i++)
   {
      
      CT[i]=CT[i-1]+Burst[i];
      Wt[i]=TAT[i-1]-1;
      TAT[i]=Burst[i]+Wt[i];
             
   }
     
}      

public void display()
{   int totalwt=0;
int totaltat=0;
    opt();
    System.out.println("Job name\t"+"Arrival time\t"+"Burst time\t"+"Waiting\t"+"CT\t"+"TAT");
    for(int i=0;i<job;i++)
    {
        System.out.println(name[i]+"\t\t"+Arrival[i]+"\t\t"+Burst[i]+"\t\t"+Wt[i]+"\t"+CT[i]+"\t"+TAT[i]);
    }
    for(int i=0;i<job;i++)
    {
     totalwt=totalwt+Wt[i];
     totaltat=totaltat+TAT[i];
    }
     avg=(float)totalwt/job;
     avg1=(float)totaltat/job;
     System.out.println("average wt is: "+avg);
     System.out.println("average tat is: "+avg1);
}

   public static void main(String s[])   
   {
     process p=new process();
     p.sort();
     p.opt();
     p.display();
   }
}

