#include<iostream>
using namespace std;
bool is_present(int n,int frame[],int f)
{
    int flag=0;
    for(int i=0;i<f;i++)
    {
        if(frame[i]==n)
        {
            flag=1;
            break;
        }
    }
    if(flag==1)
    return true;
    else 
    return false;
}
int search(int frame[],int f,int sequence[],int s,int j)
{
    int flag=0;
    int min=INT8_MAX;
    cout<<" min = "<<min<<endl;
    cout<<" frame size : = "<<f<<endl;
    cout<<"========================================= "<<endl;
    for(int i=0;i<f;i++)
    {
        flag=0;
         cout<<" i : = "<<i<<endl;
         cout<<"---------------------------------------- "<<endl;
        for(int k=f;k<j;k++)
        {
            cout<<"  k = "<<k<<endl;
            cout<<"  j = "<<j<<endl;
            cout<<"========================================= "<<endl;
            if(frame[i]==sequence[k])
            {
                flag=1;
                if(i<min)
                {
                    min=i;
                    cout<<" min = "<<min<<endl;
                }
            }
        }
        if(flag==0)
        {
            cout<<" flag i = "<<i<<endl;
            return i;
        }
    }
    
    return min;
}
int main()
{
    int s,m;
    cout<<"Enter the number of pages: ";
    cin>>s;
    
    int sequence[s];
    cout<<"Enter the name of pages: "<<endl;
    for(int i=0;i<s;i++)
    {
        cin>>sequence[i];
    }
    int f;
    cout<<"Enter the number of frames: ";
    cin>>f;
    int faults=f,hits=0,p=0,max=0;
    int frame[f];
    for(int i=0;i<f;i++)
    {
        frame[i]=sequence[i];

    }
    for(int i=f;i<s;i++)
    {
        if(!is_present(sequence[i],frame,f))
        {
            m=search(frame,f,sequence,s,i);
             cout<<"  m = "<<m<<endl;
            frame[m]=sequence[i];
            cout<<"**************************************** "<<endl;
            for(int i=0;i<f;i++)
            {
            	cout<<"["<<frame[i]<<"]"<<endl;
            }
            cout<<"*********************************** "<<endl;
            faults++;
        }
        else 
        
            hits++;
    }
    cout<<"faults: "<<faults<<endl;
    cout<<"Hits: "<<hits<<endl;


    return 0;
}
