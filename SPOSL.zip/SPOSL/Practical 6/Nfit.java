import java.util.*;

class Firstfit
{
public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	int n1,n2;
	System.out.print("\nEnter number of Memory Remaining : ");
	n1=sc.nextInt();
	System.out.print("\nEnter number of Processes : ");
	n2=sc.nextInt();
	int memorysize[]=new int[n1];	
	int processize[]=new int[n2];
	int allocation[]=new int[n2];
	int f[]=new int[n1];
	int c;
	for(int i=0;i<n2;i++)
	{
		allocation[i]=-1;
	}
	
	System.out.print("\nEnter Memory  :");
	for(int i=0;i<n1;i++)
	{
		System.out.print("\n M"+(i+1)+"= ");
		memorysize[i]=sc.nextInt();
		f[i]=0;
	}	
	
	System.out.print("\nEnter Processes  :");
	for(int i=0;i<n2;i++)
	{
		System.out.print("\n P"+(i+1)+"= ");
		processize[i]=sc.nextInt();
		
	}
	
	int j=0;
	for(int i=0;i<n2;i++)
	{
		c=j%(n1-1);
		//System.out.print("\n c = "+c);
		for(j=c;j<n1;j++)
		{
			if(memorysize[j]>=processize[i] && f[j]==0)
			{
				allocation[i]=j;
				memorysize[j]=processize[i];
				c=j;
				f[j]=1;
				break;
			}
		}
	}
	System.out.println("\n process no \t process size \t memory no.");
	for(int i=0;i<n2;i++)
	{
		System.out.print("  "+(i+1)+"\t\t " +processize[i]+" \t\t  ");
		if(allocation[i]!=-1)
			System.out.print(allocation[i]+1);
		else
			System.out.print("Not Allocated ");
		System.out.println();
	}
	
	
	
	
}
}
