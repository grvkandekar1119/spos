#include <jni.h>        
#include <stdio.h>      
#include "msg.h"   
 
JNIEXPORT void JNICALL Java_msg_sayHello(JNIEnv *env, jobject thisObj)
{
   printf("Hello Hii!\n");
   return;
}
