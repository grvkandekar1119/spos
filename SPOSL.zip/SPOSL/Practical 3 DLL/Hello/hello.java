import java.util.*;
public class hello {  // Save as HelloJNI.java
   static {
      System.loadLibrary("math"); 
   }
 
   // Declare an instance native method sayHello() which receives no parameter and returns void
   private native void sayHello();
 
   // Test Driver
   public static void main(String arg[]) throws Exception{
      new hello().sayHello();  // Create an instance and invoke the native method
   }
}
